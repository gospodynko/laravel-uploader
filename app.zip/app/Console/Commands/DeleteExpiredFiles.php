<?php

namespace App\Console\Commands;

use App\Jobs\SendEmailNotificationJob;
use App\Models\UploadedFile;
use App\Jobs\DeleteFile;
use Illuminate\Console\Command;

class DeleteExpiredFiles extends Command
{
    protected $signature = 'files:cleanup';
    protected $description = 'Удаление файлов старше 24 часов';

    public function handle()
    {
        $expiredFiles = UploadedFile::where('expires_at', '<', now())->get();

        foreach ($expiredFiles as $file) {
            DeleteFile::dispatch($file->path, $file->id)->onQueue('uploads');
//            SendEmailNotificationJob::dispatch($file)->onQueue();
        }

        $this->info(count($expiredFiles) . ' файлов отправлено на удаление.');
    }
}
