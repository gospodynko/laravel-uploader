<?php

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class FileDeleted
{
    use Dispatchable, SerializesModels;

    private $file;
    private $sendEmail;

    public function __construct($file, $sendEmail = false)
    {
        $this->setFile($file);
        $this->setSendEmail($sendEmail);
    }

    public function getFile()
    {
        return $this->file;
    }

    public function setFile($file)
    {
        $this->file = $file;
    }

    public function getSendEmail()
    {
        return $this->sendEmail;
    }

    public function setSendEmail($sendEmail)
    {
        $this->sendEmail = $sendEmail;
    }
}
