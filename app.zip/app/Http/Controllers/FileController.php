<?php

namespace App\Http\Controllers;

use App\Models\UploadedFile;
use App\Jobs\ProcessUploadedFile;
use App\Jobs\DeleteFile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FileController extends Controller
{
    // Загрузка файла
    public function upload(Request $request)
    {
        $request->validate([
            'file' => 'required|file|max:10240',
        ]);

        $file = $request->file('file');
        $path = $file->store('uploads/tmp');
        $filename = $file->getClientOriginalName();
        $userId = auth()->id() ?? 0;

        // Сохраняем в БД (файл пока временный)
        $uploadedFile = UploadedFile::create([
            'filename' => $filename,
            'path' => $path,
            'user_id' => $userId,
            'expires_at' => now()->addMinute()
//            'expires_at' => now()->addDay()
        ]);

        // Отправляем на обработку через RabbitMQ
        ProcessUploadedFile::dispatch($uploadedFile->id)->onQueue('uploads');

        return response()->json(['message' => 'Файл загружен и отправлен на обработку']);
    }

    // Отображение загруженных файлов
    public function index()
    {
        return view('files', ['files' => UploadedFile::latest()->get()]);
    }

    // Удаление файла через очередь RabbitMQ
    public function destroy($id)
    {
        $file = UploadedFile::findOrFail($id);
        DeleteFile::dispatch($file->path, $id)->onQueue('uploads');

        return response()->json(['message' => 'Файл будет удален']);
    }
}
