<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jobs\ProcessUploadedFile;
use Illuminate\Support\Facades\Storage;

class FileUploadController extends Controller
{
    public function upload(Request $request)
    {
        $request->validate([
            'file' => 'required|file|max:10240', // 10MB
        ]);

        // Сохраняем файл во временное хранилище
        $path = $request->file('file')->store('uploads/tmp');
        $userId = auth()->id() ?? 0; // Если null, ставим 0

        // Отправляем в RabbitMQ на обработку
        ProcessUploadedFile::dispatch($path, $userId)->onQueue('uploads');

        return response()->json(['message' => 'Файл загружен, идет обработка']);
    }
}
