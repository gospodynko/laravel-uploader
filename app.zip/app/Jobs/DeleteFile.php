<?php

namespace App\Jobs;

use App\Models\UploadedFile;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Storage;

class DeleteFile implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected string $path;
    protected int $fileId;

    public function __construct(string $path, int $fileId)
    {
        $this->path = $path;
        $this->fileId = $fileId;
    }

    public function handle()
    {
        // Удаляем файл с диска
        Storage::delete($this->path);

        // Удаляем запись из БД
        UploadedFile::destroy($this->fileId);
    }
}
