<?php

namespace App\Jobs;

use App\Services\RabbitMqService;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SendEmailNotificationJob implements ShouldQueue
{
    use Dispatchable, Queueable, SerializesModels;

    protected $file;

    // Конструктор для передачи файла в Job
    public function __construct($file)
    {
        $this->file = $file;
    }

    // Метод handle выполняет задачу
    public function handle(RabbitMqService $rabbitMqService)
    {
        // Отправка email через RabbitMQ
        $rabbitMqService->sendEmailNotification($this->file);
    }
}

