<?php

namespace App\Observers;

use App\Events\FileDeleted;
use App\Jobs\SendEmailNotificationJob;

class FileDeletedObserver
{
    public function handle(FileDeleted $event)
    {
        // Если нужно отправить email, ставим задачу в очередь
        if ($event->getSendEmail()) {
            SendEmailNotificationJob::dispatch($event->getFile());
        }
    }
}
