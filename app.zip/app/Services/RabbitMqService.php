<?php
namespace App\Services;

use PhpAmqpLib\Message\AMQPMessage;
use PhpAmqpLib\Connection\AMQPStreamConnection;

class RabbitMqService
{
    protected $connection;
    protected $channel;

    public function __construct()
    {
        $this->connection = new AMQPStreamConnection(
            env('RABBITMQ_HOST'),
            env('RABBITMQ_PORT'),
            env('RABBITMQ_USER'),
            env('RABBITMQ_PASSWORD'),
            env('RABBITMQ_VHOST')
        );
        $this->channel = $this->connection->channel();
    }

    public function sendEmailNotification($file)
    {
        // Формируем данные для email
        $emailData = [
            'subject' => 'File Deleted',
            'body' => "The file {$file['name']} was deleted.",
            'to' => 'recipient@example.com'
        ];


        $messageBody = json_encode($emailData);
        $message = new AMQPMessage($messageBody);

        // Отправляем сообщение в RabbitMQ
        $this->channel->basic_publish($message, 'email_exchange', 'email_queue');
    }

    public function __destruct()
    {
        $this->channel->close();
        $this->connection->close();
    }
}
